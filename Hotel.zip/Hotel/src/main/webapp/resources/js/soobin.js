$(function() {
	loginbtn();
});
function loginbtn() {
	var session=sessionStorage.getItem('id');
	$('#logout').hide();
	if ( session!=null) {
		$('#signup').hide();
		$('#login').hide();
		$('#logout').show();
	} 
	;
}
