/*$(function(){
	ajax();
});

function ajax(){*/

var regSpacing = /\s/g;
var regId = /^[a-z0-9]{6,15}$/g;
var regPw = /^[A-Za-z0-9\!\@\#\$\%\^\&\*\(\)]{6,15}$/g;
var regName = /^[가-힣]{2,15}$/g;
var regPhone = /^01([0|1|6|7|8|9]?)([0-9]{3,4})([0-9]{4})$/g;
var regSSNumber = /^([0-9]{6})?([0-9]{7})$/g;
///^[0-9]{13}$/g;
// 아이디 유효성 검사
$("#customerId").blur(function() {
	var customerId = $('#customerId').val();
	$.ajax({
		url : '/checkId?customerId='+ customerId,
		type : 'get',
		success : function(data) {
			console.log("1 = 중복o / 0 = 중복x : "+ data);							
			
			if (data == 1) {
					// 1 : 아이디가 중복되는 문구
					$("#checkId").text("사용중인 아이디입니다 !");
					$("#checkId").css("color", "red");
					/*$("#reg_submit").attr("disabled", true);*/
				} else {
					
					if(regId.test(customerId)){
						// 0 : 아이디 길이 / 문자열 검사
						$("#checkId").text("");
						/*$("#reg_submit").attr("disabled", false);*/
			
					} else if(customerId == ""){
						
						$('#checkId').text('아이디를 입력해주세요 :)');
						$('#checkId').css('color', 'red');
						/*$("#reg_submit").attr("disabled", true);*/				
						
					} else {
						
						$('#checkId').text("아이디는 소문자와 숫자 6~15자리만 가능합니다 !");
						$('#checkId').css('color', 'red');
						/*$("#reg_submit").attr("disabled", true);*/
					}
					
				}
			}, error : function() {
					console.log("실패");
			}
		});
	})
	
// 비밀번호 유효성 검사
	// 정규식 체크
$('#customerPw').blur(function() {
	if(regPw.test($(this).val())) {
		console.log('true');
		$('#checkPw').text('');
	} else {
		console.log('false');
		$('#checkPw').text('대,소문자 영어, 숫자, 특수문자 !,@,#,$,%,^,&,*,(,) 를 포함한 6~15자리');
		$('#checkPw').css('color', 'red');
	}
});
	// 비밀번호 일치 확인
$('#customerPw2').blur(function() {
	if($('#customerPw').val() != $(this).val()) {
		$('#checkPw2').text('비밀번호가 일치하지 않습니다 !');
		$('#checkPw2').css('color', 'red');
	} else {
		$('#checkPw2').text('');
	}
});

// 이름 유효성 검사
$('#customerName').blur(function() {
	if(regName.test($(this).val())){
		console.log(regName.test($(this).val()));
		$('#checkName').text('');
	} else {
		$('#checkName').text('이름을 확인해주세요 !');
		$('#checkName').css('color', 'red');
	}
});

// 핸드폰번호 유효성 검사
$('#customerPhoneNumber').blur(function() {
	if(regPhone.test($(this).val())){
		console.log(regPhone.test($(this).val()));
		$('#checkPhoneNumber').text('');
	} else {
		$('#checkPhoneNumber').text('핸드폰번호를 확인해주세요 !');
		$('#checkPhoneNumber').css('color', 'red');
	}
});



var regbirth = false;

// 주민등록번호 유효성 검사
$('#SSNumber').blur(function(){
	var dateStr= $(this).val();	
	console.log(dateStr);
    var year = $((dateStr).charAt(6) <= '2')? '19' : '20';
    	year += Number(dateStr.substr(0,2)); // 입력한 값의 0번째 자리부터 2자리 숫자 (연)
    var month = Number(dateStr.substr(2,2)); // 입력한 값의 3번째 자리부터 2자리 숫자 (월)
    var day = Number(dateStr.substr(4,2)); // 입력한 값 5번째 자리부터 2자리 숫자 (일)
    console.log(year, month, day);
    var today = new Date(); // 날짜 변수 선언
    var thisYear = today.getFullYear(); // 올해 연도 가져옴
    
    if (regSSNumber.test(dateStr)){//if1 주민번호 숫자외의 문자+길이 검사(숫자로 13자리 입력)
    	console.log(dateStr+'민번 유효성 통과 이제 아래 이프문으로 가야지');
    	//숫자만 입력했을경우 아래 if문 실행
	    /*if (dateStr.length ==13) {//if2 주민번호 길이*/	    	
			// 연도의 경우 1900 보다 작거나 yearNow 보다 크다면 false를 반환합니다.
		    if (1900 > year || year > thisYear) {//if3 연월일 조건
		    	$('#checkSSNumber').text('주민등록번호를 확인해주세요 :)');
				$('#checkSSNumber').css('color', 'red');
				console.log('yearCheck');
		    }else if (month < 1 || month > 12) {
		    	$('#checkSSNumber').text('생월을 확인해주세요 :)');
				$('#checkSSNumber').css('color', 'red'); 
				console.log('month');
		    }else if (day < 1 || day > 31) {
		    	$('#checkSSNumber').text('생일을 확인해주세요 :)');
				$('#checkSSNumber').css('color', 'red'); 
				console.log('dayCheck');
		    }else if ((month==4 || month==6 || month==9 || month==11) && day==31) {
		    	$('#checkSSNumber').text('생월과 생일을 확인해주세요 !');
				$('#checkSSNumber').css('color', 'red'); 
				console.log('birthCheck');
		    }else if (month == 2) {
		    	// 윤년계산식
		       	var leapYear = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
		       	console.log('month2Check');
		       	if (day>29 || (day==29 && !leapYear)) {//if4 윤년
		     		$('#checkSSNumber').text('생월과 생일을 확인해주세요 ! (윤년주의)');
					$('#checkSSNumber').css('color', 'red'); 
					console.log('윤년');
		       	} else {
					$('#checkSSNumber').text('');
					regbirth = true;
					console.log('성공');
				}// end if4 윤년
		    } else {
		    	
		    	$('#checkSSNumber').text(''); 
		    	regbirth = true;
		    	console.log('성공');
		    }// end if3 년월일 조건
			
		/*} else {
			// 1.입력된 주민등록번호가 13자 초과할때 : auth:false
			$('#checkSSNumber').text('주민등록번호가 너무 길어요 !');
			$('#checkSSNumber').css('color', 'red');  
		}//end if2 주민등록번호 길이
*/    } else {
    	//숫자 외의 문자가 입력되었을때
    	$('#checkSSNumber').text('주민등록번호가 이상해요 !');
		$('#checkSSNumber').css('color', 'red');
		console.log('마지막');
    }//end if1 숫자만
}); // End of method /*


/* } */