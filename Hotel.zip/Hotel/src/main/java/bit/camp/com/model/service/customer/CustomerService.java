package bit.camp.com.model.service.customer;

import java.util.List;

import bit.camp.com.model.VO.mybatis.Customer;

public interface CustomerService {

	List<Customer> selectAllCustomer();// 회원목록조회
	void signUp();// 회원가입
	String searchId();// 아이디찾기
	String searchPw();// 비번찾기
	void deleteCustomer();// 탈퇴
	
	int checkId();//아이디중복체크
	int checkSSNumber();//주민등록번호 중복체크

	/////////////////////////////////////////////////////////////////////////////////////////////////

	// 회원정보
	public void CustomerModifyUpdate(Customer customerVo) throws Exception;

	// 회원정보 수정
	public void CustomerModify(Customer customerVo) throws Exception;

}
