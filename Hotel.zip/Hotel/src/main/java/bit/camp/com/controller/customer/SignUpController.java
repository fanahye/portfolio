package bit.camp.com.controller.customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import bit.camp.com.model.VO.mybatis.Customer;
import bit.camp.com.model.dao.CustomerDao;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
public class SignUpController {
	
	@Autowired(required=false)
	private CustomerDao customerdao;

	//회원가입
		@RequestMapping(value="/signUp")
		public String signUp(Model model, Customer customer) {
			
			return "customer/signUp";
		}
		
		@RequestMapping(value="/signUpProcess", method=RequestMethod.POST)
		public String signUpProcess(Model model, Customer customer) {
			customerdao.signUp(customer);
			log.info(customer);
			return "customer/login";
		}
		
		////////////////////////////////////////////////////////////////
		
		//아이디 중복 체크
		@RequestMapping(value="/checkId", produces = MediaType.APPLICATION_JSON_UTF8_VALUE )
		@ResponseBody
		public int checkId(@RequestParam("customerId") String customerId) {
			log.info("왓나요");
			//int data = customerdao.checkId(customerId);
			log.info(customerId);
			//log.info(data);
			log.info(customerdao.checkId(customerId));
			
			return customerdao.checkId(customerId);
		}
		
		
		
}
